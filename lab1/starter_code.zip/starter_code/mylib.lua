#!lua name=mylib
