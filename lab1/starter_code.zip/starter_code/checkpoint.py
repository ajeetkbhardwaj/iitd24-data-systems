from mrds import MyRedis

def create_checkpoints(rds: MyRedis, interval: int):
  # TODO: Create a different thread that creates a checkpoint every interval seconds
  pass
